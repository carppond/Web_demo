<template>
    <div class="question-container">
        问答
    </div>
</template>

<script>
export default {
  // 组件名
  name: 'QuestionIndex',
  // 子组件映射
  components: {},
  // 父传子,数据接收
  props: {},
  // 自定义属性
  data () {
    return {}
  },
  // 计算属性
  computed: {},
  // 侦听器
  watch: {},
  // 生命周期方法 - 初始化完成
  created () {},
  // 生命周期方法 - 挂载完成
  mounted () {},
  // 定义方法
  methods: {}
}
</script>

<style lang="less" scoped>

</style>
